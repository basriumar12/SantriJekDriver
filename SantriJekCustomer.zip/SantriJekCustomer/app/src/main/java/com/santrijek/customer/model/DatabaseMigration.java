package com.santrijek.customer.model;

import io.realm.DynamicRealm;
import io.realm.RealmMigration;

/**
 * Created by bradhawk on 10/17/2016.
 */

public class DatabaseMigration implements RealmMigration {

    @Override
    public void migrate(DynamicRealm realm, long oldVersion, long newVersion) {
    }

}
