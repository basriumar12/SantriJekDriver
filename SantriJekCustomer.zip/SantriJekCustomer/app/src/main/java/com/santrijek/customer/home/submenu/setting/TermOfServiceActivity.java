package com.santrijek.customer.home.submenu.setting;

import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;

import com.santrijek.customer.R;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.IOException;

import butterknife.BindView;
import butterknife.ButterKnife;

public class TermOfServiceActivity extends AppCompatActivity {
    @BindView(R.id.web_view)
    WebView webView;

    String mUrl = "https://santrijek.com/ketentuan-layanan/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_term_of_service);
        ButterKnife.bind(this);

        webView.clearCache(true);
        webView.clearHistory();
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        Document document = null;
        try {
            // fix android.os.NetworkOnMainThreadException on Jsoup
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);

            document = Jsoup.connect(mUrl).get();
        } catch (IOException e) {
            e.printStackTrace();
        }
        document.getElementsByClass("header").remove();
        document.getElementsByClass("footer").remove();
        webView.loadDataWithBaseURL(mUrl,document.toString(),"text/html","utf-8","");
        //webView.loadUrl(mUrl);

    }

}
