package com.santrijek.customer.config;

/**
 * Created by haris on 11/25/16.
 */

public class ChatConfig {
    public static final int CHAT_ME = 0;
    public static final int CHAT_YOU = 1;

}
