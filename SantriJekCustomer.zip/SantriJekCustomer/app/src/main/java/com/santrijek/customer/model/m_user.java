package com.santrijek.customer.model;

public class m_user {


    public String name;
    public String phone;
    public String email;
}
