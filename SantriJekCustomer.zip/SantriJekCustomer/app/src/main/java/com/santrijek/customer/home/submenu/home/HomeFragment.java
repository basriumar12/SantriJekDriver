package com.santrijek.customer.home.submenu.home;

import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v7.widget.CardView;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.mikepenz.fastadapter.FastAdapter;
import com.mikepenz.fastadapter.IAdapter;
import com.mikepenz.fastadapter.adapters.FastItemAdapter;
import com.santrijek.customer.R;
import com.santrijek.customer.SantriJekApplication;
import com.santrijek.customer.adapter.ItemOffsetDecoration;
import com.santrijek.customer.api.Constant;
import com.santrijek.customer.api.ServiceGenerator;
import com.santrijek.customer.api.service.BookService;
import com.santrijek.customer.api.service.UserService;
import com.santrijek.customer.barcode.ScanActivity;
import com.santrijek.customer.home.submenu.TopUpActivity;
import com.santrijek.customer.home.submenu.setting.UpdateProfileActivity;
import com.santrijek.customer.mBox.BoxActivity;
import com.santrijek.customer.mBox.CargoItem;
import com.santrijek.customer.mFood.FoodActivity;
import com.santrijek.customer.mFood.KategoriItemHome;
import com.santrijek.customer.mFood.KategoriSelectActivity;
import com.santrijek.customer.mFood.SlideRestoFragment;
import com.santrijek.customer.mLaundry.LaundryActivity;
import com.santrijek.customer.mLaundry.LaundryItemHome;
import com.santrijek.customer.mLaundry.LaundryMenuActivity;
import com.santrijek.customer.mLaundry.SlideLaundryFragment;
import com.santrijek.customer.mMart.MartActivity;
import com.santrijek.customer.mMassage.MassageActivity;
import com.santrijek.customer.mRideCar.RideCarActivity;
import com.santrijek.customer.mSend.SendActivity;
import com.santrijek.customer.mService.mServiceActivity;
import com.santrijek.customer.model.Banner;
import com.santrijek.customer.model.DataLaundry;
import com.santrijek.customer.model.DataRestoran;
import com.santrijek.customer.model.Fitur;
import com.santrijek.customer.model.KategoriRestoran;
import com.santrijek.customer.model.KendaraanAngkut;
import com.santrijek.customer.model.Laundry;
import com.santrijek.customer.model.LaundryNearMeDB;
import com.santrijek.customer.model.PromosiMFood;
import com.santrijek.customer.model.PromosiMLaundry;
import com.santrijek.customer.model.RestoranNearMeDB;
import com.santrijek.customer.model.User;
import com.santrijek.customer.model.json.book.GetDataLaundryRequestJson;
import com.santrijek.customer.model.json.book.GetDataLaundryResponseJson;
import com.santrijek.customer.model.json.book.GetDataRestoRequestJson;
import com.santrijek.customer.model.json.book.GetDataRestoResponseJson;
import com.santrijek.customer.model.json.book.GetKendaraanAngkutResponseJson;
import com.santrijek.customer.model.json.user.GetBannerResponseJson;
import com.santrijek.customer.model.json.user.GetSaldoRequestJson;
import com.santrijek.customer.model.json.user.GetSaldoResponseJson;
import com.santrijek.customer.splash.SplashActivity;
import com.santrijek.customer.utils.ConnectivityUtils;
import com.santrijek.customer.utils.Log;
import com.santrijek.customer.utils.SnackbarController;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import cn.trinea.android.view.autoscrollviewpager.AutoScrollViewPager;
import io.realm.Realm;
import me.relex.circleindicator.CircleIndicator;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment {

    @BindView(R.id.home_mCar)
    CardView buttonMangCar;

    @BindView(R.id.home_mRide)
    CardView buttonMangRide;

    @BindView(R.id.home_mSend)
    CardView buttonMangSend;

    @BindView(R.id.home_mBox)
    CardView buttonMangBox;

    @BindView(R.id.home_mMart)
    RelativeLayout buttonMangMart;
    @BindView(R.id.profil)
    RelativeLayout profil;

    @BindView(R.id.home_mMassage)
    RelativeLayout buttonMangMassage;

    @BindView(R.id.home_mFood)
    CardView buttonMangFood;

    @BindView(R.id.home_mPayBalance)
    TextView mPayBalance;

    @BindView(R.id.home_mPayBalance1)
    TextView mPayBalance1;


    @BindView(R.id.ucap)
    TextView selamat;

    @BindView(R.id.kamu)
    TextView kamu;
    @BindView(R.id.slide_viewPager1)
    AutoScrollViewPager autoScrollViewPager1;

    @BindView(R.id.slide_viewPager_indicator1)
    CircleIndicator circleIndicator1;

    @BindView(R.id.home_topUpButton)
    RelativeLayout topUpButton;

    @BindView(R.id.home_mLaundry)
    CardView buttonLaundry;

    @BindView(R.id.home_mElectronic)
    RelativeLayout buttonElektronic;

    @BindView(R.id.barcode)
    RelativeLayout barCode;

    @BindView(R.id.imghari)
    ImageView imgHari;

    @BindView(R.id.slide_viewPager)
    AutoScrollViewPager slideViewPager;

    @BindView(R.id.slide_viewPager_indicator)
    CircleIndicator slideIndicator;

    @BindView(R.id.kategori_recycler)
    RecyclerView kategoriRecyler;

    @BindView(R.id.listLaundry_recycler)
    RecyclerView daftarLaundry;

//    @BindView(R.id.cargo_type_recyclerView)
//    RecyclerView cargoTypeRecyclerView;

    @BindView(R.id.slide_viewPager2)
    AutoScrollViewPager autoScrollViewPager2;

    @BindView(R.id.slide_viewPager_indicator2)
    CircleIndicator circleIndicator2;


    private SnackbarController snackbarController;

    private Location lastKnownLocation;
    private List<KategoriRestoran> kategoriRestoran;
    private List<RestoranNearMeDB> restoran;
    private FastItemAdapter<KategoriItemHome> kategoriAdapter;


    private List<Laundry> laundryAll;
    private List<LaundryNearMeDB> laundryByLocation;
    private FastItemAdapter<LaundryItemHome> adapterListLaundry;


    private boolean requestUpdate = true;

    private boolean connectionAvailable;
    private boolean isDataLoaded = false;

    private Realm realm;
    private Realm realm1;

    private int successfulCall;

    public ArrayList<Banner> banners = new ArrayList<>();
    int featureId;
    FastItemAdapter<CargoItem> cargodapter;

    private MassageActivity activity;

    public static final String FITUR_KEY = "FiturKey";
    public static final String CARGO = "cargo";

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof SnackbarController) {
            snackbarController = (SnackbarController) context;
        }
    }

    private User loginUser;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ButterKnife.bind(this, view);

        realm1 = Realm.getDefaultInstance();
        //LoadKendaraan();
        /*
        cargodapter = new FastItemAdapter<>();
        cargoTypeRecyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 4));
        cargoTypeRecyclerView.setAdapter(cargodapter);

        cargodapter.withItemEvent(new ClickEventHook<CargoItem>() {
            @Nullable
            @Override
            public View onBind(@NonNull RecyclerView.ViewHolder viewHolder) {
                if (viewHolder instanceof CargoItem.ViewHolder) {
                    return ((CargoItem.ViewHolder) viewHolder).itemView;
                }
                return null;
            }

            @Override
            public void onClick(View v, int position, FastAdapter<CargoItem> fastAdapter, CargoItem item) {
                KendaraanAngkut selectedCargo = realm1.where(KendaraanAngkut.class).equalTo("idKendaraan", cargodapter.getAdapterItem(position).id).findFirst();
                Log.e("BUTTON","CLICKED, ID : "+selectedCargo.getIdKendaraan());
                Intent intent = new Intent(getActivity(), BoxOrder.class);
                intent.putExtra(BoxOrder.FITUR_KEY, featureId);
                intent.putExtra(BoxOrder.KENDARAAN_KEY, selectedCargo.getIdKendaraan());
                startActivity(intent);
            }
        });
        */

        kategoriAdapter = new FastItemAdapter<>();
        getDataRestoran();
        KategoriRecycler();

        adapterListLaundry = new FastItemAdapter<>();
        getDataLaundry();
        DaftarLaundryRecycler();

        buttonMangRide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onMangRideClick();
            }
        });
        profil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                profil();
            }
        });
        buttonMangCar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onMangCarClick();
            }
        });
        buttonMangSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onMangSendClick();
            }
        });
        buttonMangBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onMangBoxClick();
            }
        });
        connectionAvailable = false;
        topUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onTopUpClick();
            }
        });
        barCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Barcode();
            }
        });
        buttonMangMart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onMangMartClick();
            }
        });

        buttonMangFood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onMangFoodClick();
            }
        });
        buttonLaundry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onLaundryClick();
            }
        });
        buttonElektronic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onElectronicClick();
            }
        });
        buttonMangMassage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onMMassageClick();
            }
        });


        realm = SantriJekApplication.getInstance(getActivity()).getRealmInstance();
        getImageBanner();

        Intent intent = getActivity().getIntent();
        featureId = intent.getIntExtra(FITUR_KEY, 7);


        ucapan();
    }

    private void getImageBanner() {
        User loginUser = new User();
        if (SantriJekApplication.getInstance(getActivity()).getLoginUser() != null) {
            loginUser = SantriJekApplication.getInstance(getActivity()).getLoginUser();
        } else {
            startActivity(new Intent(getActivity(), SplashActivity.class));
            getActivity().finish();
        }

        UserService userService = ServiceGenerator.createService(UserService.class,
                loginUser.getEmail(), loginUser.getPassword());
        userService.getBanner().enqueue(new Callback<GetBannerResponseJson>() {
            @Override
            public void onResponse(Call<GetBannerResponseJson> call, Response<GetBannerResponseJson> response) {
                if (response.isSuccessful()) {
                    banners = response.body().data;
                    Log.e("Image", response.body().data.get(0).foto);
                    try {
                        MyPagerAdapter pagerAdapter = new MyPagerAdapter(getChildFragmentManager(), banners);
                        slideViewPager.setAdapter(pagerAdapter);
                        slideIndicator.setViewPager(slideViewPager);
                        slideViewPager.setInterval(3000);
                        slideViewPager.startAutoScroll(3000);
                    }catch (IllegalStateException e ){

                    } catch (NullPointerException e){

                    }
                }
            }

            @Override
            public void onFailure(Call<GetBannerResponseJson> call, Throwable t) {

            }
        });
    }

    public static class MyPagerAdapter extends FragmentPagerAdapter {
        private static int NUM_ITEMS = 5;
        public ArrayList<Banner> banners = new ArrayList<>();

        public MyPagerAdapter(FragmentManager fragmentManager, ArrayList<Banner> banners) {
            super(fragmentManager);
            this.banners = banners;
        }

        @Override
        public int getCount() {
            return banners.size();
        }

        @Override
        public Fragment getItem(int position) {
            return SlideFragment.newInstance(banners.get(position).id, banners.get(position).foto);

        }

        @Override
        public CharSequence getPageTitle(int position) {
            return "Page " + position;
        }

    }


    @Override
    public void onResume() {
        super.onResume();
        successfulCall = 0;
        connectionAvailable = ConnectivityUtils.isConnected(getActivity());
        if (!connectionAvailable) {
            if (snackbarController != null) snackbarController.showSnackbar(
                    R.string.text_noInternet, Snackbar.LENGTH_INDEFINITE, R.string.text_close,
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            return;
                        }
                    });
        } else {
            updateMPayBalance();

        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        realm.close();
    }

    private void onMangSendClick() {
        //    Toast.makeText(getActivity().getApplicationContext(), "Maaf untuk sementara layanan tidak tersedia", Toast.LENGTH_SHORT).show();

        Fitur selectedFitur = realm.where(Fitur.class).equalTo("idFitur", 5).findFirst();
        Intent intent = new Intent(getActivity(), SendActivity.class);
        intent.putExtra(SendActivity.FITUR_KEY, selectedFitur.getIdFitur());
        getActivity().startActivity(intent);


    }

    private void onTopUpClick() {
        Intent intent = new Intent(getActivity(), TopUpActivity.class);
        startActivity(intent);
    }

    private void Barcode() {
        //Toast.makeText(getActivity().getApplicationContext(), "Maaf untuk sementara layanan tidak tersedia", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(getActivity(), ScanActivity.class);
        startActivity(intent);
    }

    private void profil() {
        //Toast.makeText(getActivity().getApplicationContext(), "Maaf untuk sementara layanan tidak tersedia", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(getActivity(), UpdateProfileActivity.class);
        startActivity(intent);
    }

    private void onMangRideClick() {
//        Toast.makeText(getActivity().getApplicationContext(), "Maaf untuk sementara layanan tidak tersedia", Toast.LENGTH_SHORT).show();
        Fitur selectedFitur = realm.where(Fitur.class).equalTo("idFitur", 1).findFirst();
        Intent intent = new Intent(getActivity(), RideCarActivity.class);
        intent.putExtra(RideCarActivity.FITUR_KEY, selectedFitur.getIdFitur());
        getActivity().startActivity(intent);
    }

    private void onMangCarClick() {
        //Toast.makeText(getActivity().getApplicationContext(), "Maaf untuk sementara layanan tidak tersedia", Toast.LENGTH_SHORT).show();

        Fitur selectedFitur = realm.where(Fitur.class).equalTo("idFitur", 2).findFirst();
        Intent intent = new Intent(getActivity(), RideCarActivity.class);
        intent.putExtra(RideCarActivity.FITUR_KEY, selectedFitur.getIdFitur());
        getActivity().startActivity(intent);
    }

    private void onMangMartClick() {
        Fitur selectedFitur = realm.where(Fitur.class).equalTo("idFitur", 4).findFirst();
        Intent intent = new Intent(getActivity(), MartActivity.class);
        intent.putExtra(MartActivity.FITUR_KEY, selectedFitur.getIdFitur());
        getActivity().startActivity(intent);
    }

    private void onMangBoxClick() {
        //  Toast.makeText(getActivity().getApplicationContext(), "Maaf untuk sementara layanan tidak tersedia", Toast.LENGTH_SHORT).show();

        Fitur selectedFitur = realm.where(Fitur.class).equalTo("idFitur", 7).findFirst();
        Intent intent = new Intent(getActivity(), BoxActivity.class);
        intent.putExtra(BoxActivity.FITUR_KEY, selectedFitur.getIdFitur());
        getActivity().startActivity(intent);
    }

    private void onMMassageClick() {
        //  Toast.makeText(getActivity().getApplicationContext(), "Maaf untuk sementara layanan tidak tersedia", Toast.LENGTH_SHORT).show();
        Fitur selectedFitur = realm.where(Fitur.class).equalTo("idFitur", 6).findFirst();
        Intent intent = new Intent(getActivity(), MassageActivity.class);
        intent.putExtra(mServiceActivity.FITUR_KEY, selectedFitur.getIdFitur());
        getActivity().startActivity(intent);

    }

    private void onMangFoodClick() {
        Fitur selectedFitur = realm.where(Fitur.class).equalTo("idFitur", 3).findFirst();
        Intent intent = new Intent(getActivity(), FoodActivity.class);
        intent.putExtra(FoodActivity.FITUR_KEY, selectedFitur.getIdFitur());
        Log.d("Food", "fitur selected : " + selectedFitur + " id fitur : " + selectedFitur.getIdFitur());
        getActivity().startActivity(intent);
    }

    private void onLaundryClick() {
//        Toast.makeText(getActivity().getApplicationContext(), "Maaf untuk sementara layanan tidak tersedia", Toast.LENGTH_SHORT).show();

        Fitur selectedFitur = realm.where(Fitur.class).equalTo("idFitur", 10).findFirst();
        Intent intent = new Intent(getActivity(), LaundryActivity.class);
        intent.putExtra(LaundryActivity.FITUR_KEY, selectedFitur.getIdFitur());
        Log.d("Food", "fitur selected : " + selectedFitur + " id fitur : " + selectedFitur.getIdFitur());
        Log.e("cklik launfry", selectedFitur.getFitur() + "");
        getActivity().startActivity(intent);
    }

    private void onElectronicClick() {
        Toast.makeText(getActivity().getApplicationContext(), "Maaf untuk sementara layanan tidak tersedia", Toast.LENGTH_SHORT).show();
    }

    private void ucapan() {

        Calendar c = Calendar.getInstance();
        int timeOfDay = c.get(Calendar.HOUR_OF_DAY);

        if (timeOfDay >= 0 && timeOfDay < 10) {
            selamat.setText("Selamat Pagi");
            selamat.setTextColor(this.getResources().getColor(R.color.white));
            kamu.setTextColor(this.getResources().getColor(R.color.white));
            imgHari.setImageResource(R.drawable.bg_pagi);
        } else if (timeOfDay >= 10 && timeOfDay < 15) {
            selamat.setText("Selamat Siang");
            selamat.setTextColor(this.getResources().getColor(R.color.white));
            kamu.setTextColor(this.getResources().getColor(R.color.white));
            imgHari.setImageResource(R.drawable.bg_siang);
        } else if (timeOfDay >= 15 && timeOfDay < 18) {
            selamat.setText("Selamat Sore");
            selamat.setTextColor(this.getResources().getColor(R.color.white));
            kamu.setTextColor(this.getResources().getColor(R.color.white));
            imgHari.setImageResource(R.drawable.bg_sore);
        } else if (timeOfDay >= 18 && timeOfDay < 24) {
            selamat.setText("Selamat Malam");
            selamat.setTextColor(this.getResources().getColor(R.color.white));
            kamu.setTextColor(this.getResources().getColor(R.color.white));
            imgHari.setImageResource(R.drawable.bg_malam);
        }
    }

    private void updateMPayBalance() {
        User loginUser = SantriJekApplication.getInstance(getActivity()).getLoginUser();
        UserService userService = ServiceGenerator.createService(
                UserService.class, Constant.username, Constant.password);

        GetSaldoRequestJson param = new GetSaldoRequestJson();
        param.setId(loginUser.getId());
        userService.getSaldo(param).enqueue(new Callback<GetSaldoResponseJson>() {
            @Override
            public void onResponse(Call<GetSaldoResponseJson> call, Response<GetSaldoResponseJson> response) {
                if (response.isSuccessful()) {
                    Locale localeID = new Locale("id", "ID");
                    String formattedText = String.format(localeID, "Rp.%s",
                            NumberFormat.getNumberInstance(localeID).format(response.body().getData()));
                    String formattedText1 = String.format(localeID, "Rp.%s",
                            NumberFormat.getNumberInstance(localeID).format(response.body().getData()));
                    mPayBalance.setText(formattedText);
                    mPayBalance1.setText(formattedText1);
                    successfulCall++;

                    if (HomeFragment.this.getActivity() != null) {
                        Realm realm = SantriJekApplication.getInstance(HomeFragment.this.getActivity()).getRealmInstance();
                        User loginUser = SantriJekApplication.getInstance(HomeFragment.this.getActivity()).getLoginUser();
                        realm.beginTransaction();
                        loginUser.setmPaySaldo(response.body().getData());
                        realm.commitTransaction();
                    }
                }
            }

            @Override
            public void onFailure(Call<GetSaldoResponseJson> call, Throwable t) {

            }
        });
    }

    private void getDataRestoran() {
        if (snackbarController != null) {
            User loginUser = SantriJekApplication.getInstance(getActivity()).getLoginUser();
            BookService service = ServiceGenerator.createService(BookService.class, loginUser.getEmail(), loginUser.getPassword());
            GetDataRestoRequestJson param = new GetDataRestoRequestJson();

            service.getDataRestoran(param).enqueue(new Callback<GetDataRestoResponseJson>() {
                @Override
                public void onResponse(Call<GetDataRestoResponseJson> call, Response<GetDataRestoResponseJson> response) {
                    if (response.isSuccessful()) {
                        DataRestoran dataRestoran = response.body().getDataRestoran();
                        kategoriRestoran = dataRestoran.getKategoriRestoranList();
                        restoran = dataRestoran.getRestoranList();
                        Realm realm = SantriJekApplication.getInstance(HomeFragment.this.getActivity()).getRealmInstance();
                        realm.beginTransaction();
                        realm.delete(KategoriRestoran.class);
                        realm.copyToRealm(kategoriRestoran);
                        realm.commitTransaction();

                        realm.beginTransaction();
                        realm.delete(RestoranNearMeDB.class);
                        realm.copyToRealm(restoran);
                        realm.commitTransaction();

                        kategoriAdapter.clear();
                        KategoriItemHome kategoriItem;
                        for (KategoriRestoran kategori : kategoriRestoran) {
                            kategoriItem = new KategoriItemHome(HomeFragment.this.getActivity());
                            kategoriItem.idKategori = kategori.getIdKategori();
                            kategoriItem.kategori = kategori.getKategori();
                            kategoriItem.image = kategori.getFotoKategori();
                            kategoriAdapter.add(kategoriItem);
                            Log.e("ADD KATEGORI", kategori.getIdKategori() + "");
                        }

                        List<PromosiMFood> promosiMFoods = dataRestoran.getPromosiMFood();
//                        Toast.makeText(FoodActivity.this, "size = "+promosiMFoods.size(), Toast.LENGTH_SHORT).show();
                        MyPagerAdapter2 pagerAdapter = new MyPagerAdapter2(getChildFragmentManager(), promosiMFoods);
                        autoScrollViewPager2.setAdapter(pagerAdapter);
                        circleIndicator2.setViewPager(autoScrollViewPager2);
                        autoScrollViewPager2.setInterval(4000);
                        autoScrollViewPager2.startAutoScroll(4000);

                    }
                }

                @Override
                public void onFailure(Call<GetDataRestoResponseJson> call, Throwable t) {
                    Toast.makeText(getActivity(), "Connection to server lost, check your internet connection.",
                            Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    public static class MyPagerAdapter2 extends FragmentPagerAdapter {
        private static int NUM_ITEMS = 5;
        public List<PromosiMFood> banners = new ArrayList<>();

        public MyPagerAdapter2(FragmentManager fragmentManager, List<PromosiMFood> banners) {
            super(fragmentManager);
            this.banners = banners;
        }

        @Override
        public int getCount() {
            return banners.size();
        }

        @Override
        public Fragment getItem(int position) {
            return SlideRestoFragment.newInstance(banners.get(position).getId(),
                    banners.get(position).getFoto(),
                    banners.get(position).getIdResto());

        }

        @Override
        public CharSequence getPageTitle(int position) {
            return "Page " + position;
        }

    }

    private void KategoriRecycler() {
        kategoriRecyler.setLayoutManager(new GridLayoutManager(getActivity(), 2, LinearLayout.HORIZONTAL, false));
        ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(HomeFragment.this.getActivity(), R.dimen.item_offset);
        kategoriRecyler.addItemDecoration(itemDecoration);
        kategoriRecyler.setNestedScrollingEnabled(false);
        kategoriRecyler.setAdapter(kategoriAdapter);
        kategoriAdapter.withOnClickListener(new FastAdapter.OnClickListener<KategoriItemHome>() {
            @Override
            public boolean onClick(View v, IAdapter<KategoriItemHome> adapter, KategoriItemHome item, int position) {
                Log.e("BUTTON", "CLICKED");
//                KategoriRestoran selectedKategori = realm.where(KategoriRestoran.class).equalTo("idKategori", kategoriAdapter.getAdapterItem(position).idKategori).findFirst();
//                Intent intent = new Intent(FoodActivity.this, BoxOrder.class);
//                intent.putExtra(BoxOrder.KENDARAAN_KEY, selectedKategori.getIdKategori());
//                startActivity(intent);
                Intent intent = new Intent(HomeFragment.this.getActivity(), KategoriSelectActivity.class);
                intent.putExtra(KategoriSelectActivity.KATEGORI_ID, String.valueOf(item.idKategori));
                startActivity(intent);
                return true;
            }
        });
    }


    private void DaftarLaundryRecycler() {

        daftarLaundry.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayout.HORIZONTAL, false));
        daftarLaundry.setAdapter(adapterListLaundry);
        adapterListLaundry.withOnClickListener(new FastAdapter.OnClickListener<LaundryItemHome>() {
            @Override
            public boolean onClick(View v, IAdapter<LaundryItemHome> adapter, LaundryItemHome item, int position) {
                Log.e("BUTTON", "CLICKED");
                Intent intent = new Intent(HomeFragment.this.getActivity(), LaundryMenuActivity.class);
                intent.putExtra(LaundryMenuActivity.ID_LAUNDRY, item.id);
                intent.putExtra(LaundryMenuActivity.NAMA_LAUNDRY, item.namaLaundry);
                intent.putExtra(LaundryMenuActivity.ALAMAT_LAUNDRY, item.alamat);
                intent.putExtra(LaundryMenuActivity.DISTANCE_LAUNDRY, item.distance);
                intent.putExtra(LaundryMenuActivity.JAM_BUKA, item.jamBuka);
                intent.putExtra(LaundryMenuActivity.JAM_TUTUP, item.jamTutup);
                intent.putExtra(LaundryMenuActivity.IS_OPEN, item.isOpen);
                intent.putExtra(LaundryMenuActivity.PICTURE_URL, item.pictureUrl);
                intent.putExtra(LaundryMenuActivity.IS_MITRA, item.isMitra);
                startActivity(intent);
                return true;
            }
        });


    }

    private void getDataLaundry() {
        if (snackbarController != null) {
            User loginUser = SantriJekApplication.getInstance(getActivity()).getLoginUser();
            BookService service = ServiceGenerator.createService(BookService.class, loginUser.getEmail(), loginUser.getPassword());
            GetDataLaundryRequestJson param = new GetDataLaundryRequestJson();

            service.getDataLaundry(param).enqueue(new Callback<GetDataLaundryResponseJson>() {
                @Override
                public void onResponse(Call<GetDataLaundryResponseJson> call, Response<GetDataLaundryResponseJson> response) {
                    if (response.isSuccessful()) {
                        DataLaundry dataLaundry = response.body().getDataLaundry();
                        laundryAll = dataLaundry.getLaundryAll();
                        laundryByLocation = dataLaundry.getLaundryList();
                        Log.d(LaundryActivity.class.getSimpleName(), "Number of laundry: " + laundryAll.size());
                        Log.d(Laundry.class.getSimpleName(), "Number of laundry by location: " + laundryByLocation.size());
                        Realm realm = SantriJekApplication.getInstance(HomeFragment.this.getActivity()).getRealmInstance();
                        realm.beginTransaction();
                        realm.delete(Laundry.class);
                        realm.copyToRealm(laundryAll);
                        realm.commitTransaction();

                        realm.beginTransaction();
                        realm.delete(LaundryNearMeDB.class);
                        realm.copyToRealm(laundryByLocation);
                        realm.commitTransaction();

                        adapterListLaundry.clear();
                        LaundryItemHome laundryItem;
                        for (int i = 0; i < laundryAll.size(); i++) {
                            laundryItem = new LaundryItemHome(HomeFragment.this.getActivity());
                            laundryItem.id = laundryAll.get(i).getId();
                            laundryItem.namaLaundry = laundryAll.get(i).getNamaLaundry();
                            laundryItem.alamat = laundryAll.get(i).getAlamat();
                            laundryItem.distance = laundryAll.get(i).getDistance();
                            laundryItem.jarak = laundryAll.get(i).getDistance();
                            laundryItem.jamBuka = laundryAll.get(i).getJamBuka();
                            laundryItem.jamTutup = laundryAll.get(i).getJamTutup();
                            laundryItem.fotoLaundry = laundryAll.get(i).getFotoLaundry();
                            laundryItem.isOpen = laundryAll.get(i).isOpen();
                            laundryItem.pictureUrl = laundryAll.get(i).getFotoLaundry();
                            laundryItem.isMitra = laundryAll.get(i).isPartner();
                            adapterListLaundry.add(laundryItem);
                            Log.e("LAUNDRY", laundryItem.namaLaundry + "");
                            Log.e("LAUNDRY", laundryItem.alamat + "");
                            Log.e("LAUNDRY", laundryItem.jamBuka + "");
                            Log.e("LAUNDRY", laundryItem.jamTutup + "");
                            Log.e("LAUNDRY", laundryItem.fotoLaundry + "");

                        }
                        List<PromosiMLaundry> promosiMLaundry = dataLaundry.getPromosiMLaundry();
//                        Toast.makeText(FoodActivity.this, "size = "+promosiMFoods.size(), Toast.LENGTH_SHORT).show();
                        MyPagerAdapter1 pagerAdapter = new MyPagerAdapter1(getChildFragmentManager(), promosiMLaundry);
                        autoScrollViewPager1.setAdapter(pagerAdapter);
                        circleIndicator1.setViewPager(autoScrollViewPager1);
                        autoScrollViewPager1.setInterval(3000);
                        autoScrollViewPager1.startAutoScroll(3000);
                    }
                }

                @Override
                public void onFailure(Call<GetDataLaundryResponseJson> call, Throwable t) {
//                    Toast.makeText(getApplicationContext(), "Connection to server lost, check your internet connection.",
//                            Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    public static class MyPagerAdapter1 extends FragmentPagerAdapter {
        private static int NUM_ITEMS = 5;
        public List<PromosiMLaundry> banners = new ArrayList<>();

        public MyPagerAdapter1(FragmentManager fragmentManager, List<PromosiMLaundry> banners) {
            super(fragmentManager);
            this.banners = banners;
        }

        @Override
        public int getCount() {
            return banners.size();
        }

        @Override
        public Fragment getItem(int position) {
            return SlideLaundryFragment.newInstance(banners.get(position).getId(),
                    banners.get(position).getFoto(),
                    banners.get(position).getIdLaundry());

        }

        @Override
        public CharSequence getPageTitle(int position) {
            return "Page " + position;
        }

    }

    private void LoadKendaraan() {
        User loginUser = SantriJekApplication.getInstance(getContext()).getLoginUser();
        BookService service = ServiceGenerator.createService(BookService.class, loginUser.getEmail(), loginUser.getPassword());
        service.getKendaraanAngkut().enqueue(new Callback<GetKendaraanAngkutResponseJson>() {
            @Override
            public void onResponse(Call<GetKendaraanAngkutResponseJson> call, Response<GetKendaraanAngkutResponseJson> response) {
                if (response.isSuccessful()) {

                    Realm realm = SantriJekApplication.getInstance(getActivity()).getRealmInstance();
                    realm.beginTransaction();
                    realm.delete(KendaraanAngkut.class);
                    realm.copyToRealm(response.body().getData());
                    realm.commitTransaction();

                    CargoItem cargoItem;
                    for (KendaraanAngkut cargo : response.body().getData()) {
                        cargoItem = new CargoItem(getContext());
                        cargoItem.featureId = featureId;
                        cargoItem.id = cargo.getIdKendaraan();
                        cargoItem.type = cargo.getKendaraanAngkut();
                        cargoItem.price = cargo.getHarga();
                        cargoItem.image = cargo.getFotoKendaraan();
                        cargoItem.dimension = cargo.getDimensiKendaraan();
                        cargoItem.maxWeight = cargo.getMaxweightKendaraan();
                        cargodapter.add(cargoItem);
                        Log.e("ADD CARGO", cargo.getIdKendaraan() + "");
                    }
                }
            }

            @Override
            public void onFailure(Call<GetKendaraanAngkutResponseJson> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }


}
