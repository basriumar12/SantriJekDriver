package com.santrijek.customer.config;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;

/**
 * Created by haris on 11/25/16.
 */

public class General {
    public static final String FCM_KEY = "AIzaSyAHooAOLMfc9FlkDu5vXMVakeuj36W96BI";
    public static final LatLngBounds BOUNDS = new LatLngBounds(
            new LatLng(-4.064849, 119.284146), // southwest
            new LatLng(-3.477009, 122.827374)); // northeast
}
