package com.santrijek.customer.mMassage.event;

/**
 * Created by haris on 1/15/17.
 */

public class OnUserCancel {
}
