package com.santrijek.customer.utils;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.libraries.places.api.model.RectangularBounds;
import com.google.maps.android.SphericalUtil;

public class MapsUtil {
    public static RectangularBounds toBounds(LatLng center, double radiusInMeters) {
        double distanceFromCenterToCorner = radiusInMeters * Math.sqrt(2.0);
        LatLng southwestCorner =
                SphericalUtil.computeOffset(center, distanceFromCenterToCorner, 225.0);
        LatLng northeastCorner =
                SphericalUtil.computeOffset(center, distanceFromCenterToCorner, 45.0);

        RectangularBounds bounds = RectangularBounds.newInstance(northeastCorner, southwestCorner);

        return bounds;
    }
}
