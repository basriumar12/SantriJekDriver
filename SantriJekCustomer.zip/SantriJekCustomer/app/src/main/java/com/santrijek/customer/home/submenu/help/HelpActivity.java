package com.santrijek.customer.home.submenu.help;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.santrijek.customer.R;
import com.santrijek.customer.SantriJekApplication;
import com.santrijek.customer.api.Constant;
import com.santrijek.customer.api.ServiceGenerator;
import com.santrijek.customer.api.service.UserService;
import com.santrijek.customer.model.User;
import com.santrijek.customer.model.json.menu.HelpRequestJson;
import com.santrijek.customer.model.json.menu.HelpResponseJson;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HelpActivity extends AppCompatActivity {

    @BindView(R.id.help_title)
    TextView helpTitle;
    @BindView(R.id.help_subject)
    TextView helpSubject;
    @BindView(R.id.help_description)
    TextView helpDescription;
    @BindView(R.id.send_help_request)
    Button sendHelpRequest;

    Context context;
    private int titleId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
        ButterKnife.bind(this);
        context = getApplicationContext();
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setHelpTitle(getIntent().getIntExtra("id",1));

        sendHelpRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(helpSubject.getText().toString().length()>0&&helpDescription.getText().toString().length()>0){
                    Toast.makeText(context, "Dikirm...", Toast.LENGTH_SHORT).show();
                    User loginUser = SantriJekApplication.getInstance(HelpActivity.this).getLoginUser();
                    HelpRequestJson request = new HelpRequestJson();
                    request.id_pelanggan = loginUser.getId();
                    request.subject = helpSubject.getText().toString();
                    request.description = helpDescription.getText().toString();
                    request.type = titleId+"";

                    UserService service = ServiceGenerator.createService(UserService.class, Constant.username, Constant.password);
                    service.sendHelp(request).enqueue(new Callback<HelpResponseJson>() {
                        @Override
                        public void onResponse(Call<HelpResponseJson> call, Response<HelpResponseJson> response) {
                            if (response.isSuccessful()) {
                                if (response.body().mesage.equals("success")) {
                                    helpSubject.setText("");
                                    helpDescription.setText("");
                                    View view = HelpActivity.this.getCurrentFocus();
                                    if (view != null) {
                                        InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                                        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                                    }
                                } else {
                                    Toast.makeText(HelpActivity.this, "Failed!", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }

                        @Override
                        public void onFailure(Call<HelpResponseJson> call, Throwable t) {
                            t.printStackTrace();
                            Toast.makeText(HelpActivity.this, "System error: " + t.getLocalizedMessage(), Toast.LENGTH_LONG).show();
                        }
                    });

                }
            }
        });
    }


    private void setHelpTitle(int id){
        String titile = "";
        titleId = id;
        switch (id){
            case 0:
                titile = "Klik Ride";
                break;
            case 1:
                titile = "Klik Courier";
                break;
            case 2:
                titile = "Klik Food";
                break;
            case 3:
                titile = "Klik Taxcar";
                break;
            case 4:
                titile = "Klik Mart";
                break;
            default:
                titile = "JASA AJO";
                break;

        }
        helpTitle.setText(titile);
    }

}
