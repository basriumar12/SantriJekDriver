package com.santrijek.customer.api;

public class Constant {

    public static String username = "admin";
    public static String password = "1234";

}
