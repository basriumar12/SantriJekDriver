package com.santrijek.customer.model;

/**
 * Created by haris on 11/24/16.
 */

public class FCMType {
    public static final int ORDER = 1;
    public static final int CHAT = 2;
}
