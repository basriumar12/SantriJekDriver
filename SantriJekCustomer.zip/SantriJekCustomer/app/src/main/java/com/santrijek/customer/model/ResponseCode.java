package com.santrijek.customer.model;

/**
 * Created by haris on 11/24/16.
 */

public class ResponseCode {
    public static final int REJECT = 0;
    public static final int ACCEPT = 1;
    public static final int CANCEL = 2;
    public static final int START = 3;
    public static final int FINISH = 4;
}
