package com.santrijek.customer.splash;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;

import com.santrijek.customer.SantriJekApplication;
import com.santrijek.customer.R;
import com.santrijek.customer.api.ServiceGenerator;
import com.santrijek.customer.api.service.UserService;
import com.santrijek.customer.home.MainActivity;
import com.santrijek.customer.model.User;
import com.santrijek.customer.model.json.menu.VersionRequestJson;
import com.santrijek.customer.model.json.menu.VersionResponseJson;
import com.santrijek.customer.signIn.SignInActivity;
import com.santrijek.customer.utils.Log;

import java.util.Calendar;

import butterknife.BindView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by bradhawk on 10/12/2016.
 */

public class SplashActivity extends AppCompatActivity {


    @BindView(R.id.gambar)
    ImageView imghari;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        PackageInfo pInfo;
        VersionRequestJson request = new VersionRequestJson();
        request.version = "6";
        request.application = "0";
        try {
            pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            request.version = pInfo.versionCode + "";
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        request.version = "7";
        UserService service = ServiceGenerator.createService(UserService.class, "admin", "1234");
        service.checkVersion(request).enqueue(new Callback<VersionResponseJson>() {
            @Override
            public void onResponse(Call<VersionResponseJson> call, Response<VersionResponseJson> response) {
                final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(SplashActivity.this);
                alertDialogBuilder.setTitle("SantriJek");
                alertDialogBuilder.setMessage("New version is available.");

                if (response.isSuccessful()) {
                    if (response.body().new_version.equals("yes")) {
                        alertDialogBuilder.setMessage(response.body().message);
                        alertDialogBuilder.setPositiveButton("yes",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface arg0, int arg1) {
                                        final String appPackageName = getPackageName();
//                              final String appPackageName = "user.pacekurir.drivermangjek";
                                        try {
                                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
                                        } catch (android.content.ActivityNotFoundException anfe) {
                                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
                                        }
                                    }
                                });

                        alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                                finish();
                            }
                        });

                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();

                    } else if (response.body().new_version.equals("no")) {
                        start();
                    } else if (response.body().new_version.equals("maintenance")) {
                        Log.e("VERSION", "Maintenance");
                        alertDialogBuilder.setPositiveButton("dismiss",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int arg1) {
                                        dialog.dismiss();
                                        finish();
//                                        start();
                                    }
                                });

//                        alertDialogBuilder.setNegativeButton("No",new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialog, int which) {
//                                dialog.dismiss();
//                                start();
//                            }
//                        });
                        alertDialogBuilder.setMessage(response.body().message);
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    } else {
                        alertDialogBuilder.setPositiveButton("yes",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int arg1) {
                                        dialog.dismiss();
                                        start();
                                    }
                                });

                        alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                                start();
                            }
                        });
                        alertDialogBuilder.setMessage(response.body().message);
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    }
                }


            }

            @Override
            public void onFailure(Call<VersionResponseJson> call, Throwable t) {
                t.printStackTrace();
//                Toast.makeText(SplashActivity.this, "System error: " + t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                Log.e("System error:", t.getLocalizedMessage());
//                restartActivity();
                start();
            }
        });


    }

    private void ucapan() {

        Calendar c = Calendar.getInstance();
        int timeOfDay = c.get(Calendar.HOUR_OF_DAY);

        if (timeOfDay >= 0 && timeOfDay < 12) {
            //  selamat.setTextColor(this.getResources().getColor(R.color.white));
            //  kamu.setTextColor(this.getResources().getColor(R.color.white));
            imghari.setImageResource(R.drawable.morning);
        } else if (timeOfDay >= 12 && timeOfDay < 16) {
            imghari.setImageResource(R.drawable.noon);
        } else if (timeOfDay >= 16 && timeOfDay < 21) {
            imghari.setImageResource(R.drawable.afternoon);
        } else if (timeOfDay >= 21 && timeOfDay < 24) {
            imghari.setImageResource(R.drawable.night);
        }
    }

    private void restartActivity() {
        Intent intent = getIntent();
        finish();
        startActivity(intent);
    }

    private void start() {
        new CountDownTimer(3000, 3000) {

            @Override
            public void onTick(long l) {

            }

            @Override
            public void onFinish() {
                User user = SantriJekApplication.getInstance(getBaseContext()).getLoginUser();
                Intent intent;
                if (user != null) {
                    intent = new Intent(SplashActivity.this, MainActivity.class);

                } else {
                    intent = new Intent(SplashActivity.this, SignInActivity.class);
                }
                startActivity(intent);
            }
        }.start();
    }

}
