package com.santrijek.driver.model;

import java.io.Serializable;

/**
 * Created by GagahIB on 27/11/2016.
 */
public class DestinasiMbox implements Serializable{

    public int id;
    public int id_transaksi;
    public String nama_penerima;
    public String telepon_penerima;
    public String lokasi;
    public String detail_lokasi;
    public String latitude;
    public String longitude;
    public String instruksi;
}
