package com.santrijek.driver.model;

/**
 * Created by GagahIB on 27/11/2016.
 */
public class RiwayatTransaksi {

    public String id_transaksi;
    public String waktu_riwayat;
    public String nama_depan;
    public String nama_belakang;
    public String jarak;
    public String alamat_asal;
    public String alamat_tujuan;
    public int debit;
    public int kredit;
    public int saldo;
    public String biay_akhir;
    public String tipe_transaksi;
    public String id_fitur;
    public String fitur;
    public String keterangan;
}
