package com.santrijek.driver.model;

import java.io.Serializable;

/**
 * Created by GagahIB on 27/11/2016.
 */
public class MakananBelanja implements Serializable{


    public int id_makanan;
    public String nama_makanan;
    public int jumlah_makanan;
    public int harga_makanan;
    public String catatan_makanan;

}
