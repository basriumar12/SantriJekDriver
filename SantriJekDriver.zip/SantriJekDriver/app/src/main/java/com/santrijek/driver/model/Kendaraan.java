package com.santrijek.driver.model;

/**
 * Created by GagahIB on 19/10/2016.
 */
public class Kendaraan {

    public String id;
    public String jenisKendaraan;
    public String merek;
    public String tipe;
    public String nopol;
    public String warna;
}
