package com.santrijek.driver.model;

import java.io.Serializable;

/**
 * Created by GagahIB on 26/10/2016.
 */
public class Feedback implements Serializable{

    public String id;
    public String catatan;
    public long waktu;
}
