package com.santrijek.driver.model;

/**
 * Created by GagahIB on 19/10/2016.
 */
public class Driver {

    public String id;
    public String name;
    public String phone;
    public String email ="admin";
    public String password="1234";
    public String image;
    public int deposit;
    public String rating;
    public String gcm_id;
    public int status;
    public int job;
    public String nama_bank;
    public String atas_nama;
    public String no_rek;
    public String latitude;
    public String longitude;
}
