package com.santrijek.driver.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by GagagIB on 30/11/2016.
 */
public class BootCompleteBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
//        Intent service = new Intent(context, MyFirebaseMessagingService.class);
//        context.startService(service);
    }
}
