package com.santrijek.driver.model;

import java.io.Serializable;

/**
 * Created by GagahIB on 27/11/2016.
 */
public class LaundryBelanja implements Serializable{

    public int id_item_laundry;
    public String nama_menu;
    public int jumlah_laundry;
    public int harga_laundry;
    public String catatan_laundry;

}
