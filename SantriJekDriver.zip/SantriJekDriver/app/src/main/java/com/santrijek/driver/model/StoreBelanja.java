package com.santrijek.driver.model;

import java.io.Serializable;

/**
 * Created by GagahIB on 27/11/2016.
 */
public class StoreBelanja implements Serializable{

    public int id_barang;
    public String nama_barang;
    public int jumlah_barang;
    public int harga_barang;
    public String catatan_barang;

}
